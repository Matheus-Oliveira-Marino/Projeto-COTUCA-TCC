README:
This mod requires the Dreaming Demon Faceguard appearance equipped or refashioned. 
Please let me know if it's incompatible with any others and i'll try to follow up with updates. 

Installation:
-Download and install the Nioh 2 Mod Enabler
-Download main file and unzip
-Copy/paste this mod into your "Mods" directory
-Restart Game or press F10