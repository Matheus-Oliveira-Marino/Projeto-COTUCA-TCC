Extract third party mods here.

You don't need to restart the game after installing a new mod - just press F10
while the game is running to reload all the mods in this directory.
