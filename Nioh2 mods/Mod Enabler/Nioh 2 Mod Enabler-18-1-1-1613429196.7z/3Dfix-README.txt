Nioh 2 Mod Enabler v1.1
===================================

Mods
------------
You don't need to restart the game after installing a new mod - just press F10 in
game to load any new mods.

Some mods included ship with optional parts that are not enabled by
default - look for any files or directories in the mod pack that is named
"DISABLED something", and remove the "DISABLED" from the filename to enable it.

Installing
------------------------------------------
Extract the contents of the 7z file to the game directory.

Keys
------------------------------------
- F1: Show help
- F2: Toggle costume mods
- Shift+F2: Cycle mod shadow modes (on/off/original)
- Mouse back button: Toggle HUD visibility
- Ctrl+F9: 3DMigoto performance monitor
- F10: Reload all mods
- Ctrl+Alt+F10: Reload all mods and reset to default configuration

Authors
-------------
Fixing games takes a lot of time and effort, and I also do a lot of work on
3DMigoto behind the scenes to make all of these mods possible.

If you are in a position where you are able to do so, please consider
[supporting me with a monthly donation on Patreon][1], and thanks again to
those that already do! While I prefer the more stable monthly support that
Patreon offers, I can of course understand that some of you prefer to make
one-off donations when you can, and for that you can use [my Paypal][2]. As a
reminder, these donations are to support me personally, and do not go to other
modders on this site.

[1]: https://www.patreon.com/DarkStarSword
[2]: https://www.paypal.me/DarkStarSword

This mod is created with 3DMigoto (primarily written by myself, Bo3b and
Chiri), and uses Flugan's Assembler. See [here][3] for a full list of
contributors to 3DMigoto_

[3]: https://darkstarsword.net/3Dmigoto-stats/authors.html

From Anika / etsorhtt:
"I have done minimal amount of work to get this working with Nioh 2, all credits go to
DarkStarSword / ausgeek, main developer behind 3DMigoto and DOAXVV 3D Vision 
+ Costume Mod Enabler this is based on."
