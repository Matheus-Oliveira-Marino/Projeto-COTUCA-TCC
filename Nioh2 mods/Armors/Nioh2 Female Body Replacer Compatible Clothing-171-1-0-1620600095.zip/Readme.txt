Copy all folders except the option files folder to the nioh2 mods folder.

Select the type of clothing you want to install from the options file, and copy the 01_Shinobi Robes folder,
 02_Onmyo Hunting Garb folder, and 03_Sohaya Garb Shawl to the nioh2 mods folder. 